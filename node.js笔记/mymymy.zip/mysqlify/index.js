var db = require('./core');
exports = module.exports = db;