var config = {
	db: {
		host: '121.43.158.123',
		port: '3306',
		user: 'root',
		password: 'jk2018as',
		database: 'test'
	},

	test: {
		
	}
};

exports = module.exports = config;