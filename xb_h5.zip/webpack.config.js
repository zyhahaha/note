const path = require('path');
const webpack = require('webpack');
const ExtractTextPlugin = require("extract-text-webpack-plugin");
// const HtmlWebpackPlugin = require('html-webpack-plugin');
const extractSass = new ExtractTextPlugin({
  filename: "assets/css/[name].[contenthash].css"
  //disable: process.env.NODE_ENV === "development"
});
function resolve (dir) {
  return path.join(__dirname, '.', dir)
}

const config = require('./config');
let prod = (process.env.NODE_ENV === 'production');
let webpackConfig = {
  entry: config.entry,
  output: {
    path: path.resolve(__dirname, "dist"),
    filename: "assets/js/[name].[hash].js",
    publicPath: "/"
  },
  module: {
    rules: [{
      test: /\.less$/,
      use: extractSass.extract({
        use: [{
          loader: "css-loader",
          options: {
            sourceMap: true,
            minimize: prod
          }
        }, {
          loader: "less-loader",
          options: {
            sourceMap: true
          }
        }],
        // use style-loader in development
        fallback: "style-loader"
      })
    }, {
      test: /\.css$/,
      use: [
        'style-loader',
        {
          loader: "css-loader",
          options: {
            sourceMap: true,
            minimize: prod
          }
        }]
    },
    {
      test: /\.js?$/,
      include: [
        path.resolve(__dirname, "src")
      ],      
      loader: "babel-loader"      
    },
    {
      test: /\.vue$/,
      loader: 'vue-loader'
    },
    //{ test: /\.jpg$/, use: ["file-loader"] },
    {
      test: /\.png|\.jpg|woff|woff2|ttf|eot|svg|swf$/,
      use: [{
        loader: 'url-loader',
        options: {
          // mimetype: "image/png",
          limit: 8192
        }
      }]
    },
    {
      test: /\.html$/,
      use: [{
        loader: 'html-loader',
        options: {
          minimize: true
          //attrs: [':src']
        }
      }],
    }
    ]
  },
  resolve: {     
    extensions: [".js", ".json", ".css"],
    // extensions that are used    
    alias: {
      'vue$': 'vue/dist/vue.esm.js',
      '@': resolve('src')
    }
  },
  performance: {
    hints: "warning", // enum
    maxAssetSize: 200000, // int (in bytes),
    maxEntrypointSize: 400000, // int (in bytes)
    assetFilter: function (assetFilename) {
      // Function predicate that provides asset filenames
      return assetFilename.endsWith('.css') || assetFilename.endsWith('.js');
    }
  },
  //devtool: "source-map",
  context: __dirname,
  target: "web",
  //externals: ["react", /^@angular\//],
  stats: "errors-only",
  devServer: {
    proxy: {
      '/elearning-app': {
        target: 'http://10.10.1.14:8090',
        pathRewrite: {
            '^/elearning-app': '/elearning-app'
        },
      },
      '/api': {
        target: "http://10.10.1.8:9230",
        changeOrigin: true,
        pathRewrite: {
          '^/api': ''
        }
      },
      '/dev': {
        target: 'http://10.10.1.8:9230',
        pathRewrite: { "^/dev": "" }
      }
    },
    port: 8889,
    disableHostCheck: true,
    contentBase: path.join(__dirname, 'dist'), // boolean | string | array, static file location
    compress: true, // enable gzip compression
    historyApiFallback: true, // true for index.html upon 404, object for multiple paths
    hot: true, // hot module replacement. Depends on HotModuleReplacementPlugin
    https: false, // true for self-signed, object for cert authority
    noInfo: true // only errors & warns on hot reload       
  },
  plugins: [extractSass].concat(config.plugins),
  profile: true,
  recordsPath: path.resolve(__dirname, "build/records.json"),
  recordsInputPath: path.resolve(__dirname, "build/records.json"),
  recordsOutputPath: path.resolve(__dirname, "build/records.json")
};
if (prod) {
  webpackConfig.plugins = webpackConfig.plugins.concat([
    new webpack.optimize.MinChunkSizePlugin({
      minChunkSize: 1000// Minimum number of characters
    }),
    //压缩
    new webpack.optimize.UglifyJsPlugin({
      compress: {
        //supresses warnings, usually from module minification
        warnings: false,
        drop_console: true,
        drop_debugger: true
      },
      comments: false,
    })
  ]);
} else {
  webpackConfig.plugins = webpackConfig.plugins.concat([
    new webpack.SourceMapDevToolPlugin({
      filename: '[name].js.map',
      exclude: ['index.js']
    })
  ]);
}
module.exports = webpackConfig;