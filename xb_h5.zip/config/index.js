const HtmlWebpackPlugin = require('html-webpack-plugin');
const webpack = require('webpack');
const CopyWebpackPlugin = require('copy-webpack-plugin');
module.exports = {
    entry: {
        // billData: ['./src/billData.js'],
        courseware: ['./src/pages/courseware/courseware.js']
    },
    plugins: [
        // new HtmlWebpackPlugin({
        //     chunks: ['billData'],
        //     filename: './billData.html',
        //     template: './billData.html',
        //     minify: {
        //         removeComments: true,
        //         collapseWhitespace: true
        //     }
        // }),
        new HtmlWebpackPlugin({
            chunks: ['courseware'],
            filename: './courseware.html',
            template: './src/pages/courseware/courseware.html',
            minify: {
                removeComments: true,
                collapseWhitespace: true
            }
        }),
        new webpack.DefinePlugin({
            'isProd': process.env.NODE_ENV === 'production'             
        }),
        new CopyWebpackPlugin([
            // { from: 'images', to: 'images' },           
            // { from: 'js', to: 'js' },
            // { from: 'index.html', to: 'index.html' }
            // { from: 'tableData.html', to: 'tableData.html' },
            // { from: 'orderData.html', to: 'orderData.html' },
            // { from: 'turnover.html', to: 'turnover.html' }
        ])        
        // new HtmlWebpackPlugin({
        //     chunks: ['turnover'],
        //     filename: './turnover.html',
        //     template: './turnover.html',
        //     minify: {
        //         removeComments: true,
        //         collapseWhitespace: true
        //     }
        // }),
    ]
}