import axios from 'axios';
import FastClick  from 'fastclick'

import './style/courseware.less';

// 兼容部分机型延迟300s的问题
if ('addEventListener' in document) {
    document.addEventListener('DOMContentLoaded', function () {
        FastClick.attach(document.body);
    }, false);
}

let baseUrl = '/elearning-app';
if (isProd) {
  baseUrl = '';
}
